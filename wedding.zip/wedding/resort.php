<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resort</title>
</head>
<body>
    <h1><b>Our Resort</b></h1>
    <img src="images/resort1.jpg" alt="This is an image"width="100%"height="600px";>
  
        <p>Feeling of serenity will slowly follow, as you drive further through the ancient pine tree forest to our state of the art retreat. Upon entering, you are bound to be allured by the striking element of design, the one of its kind walkthrough aquarium. 
            When you cross the threshold of reality, its exotic marine inhabitants shall lead you towards the inner falls, which guides you down into the majestic winter garden, indoor aqua park and the jewel of our property — 115m long filtered seawater pool built into mindfully designed panoramic deck.</p>
   

    
</body>
</html>
<style>

h1{
    margin-left: 620px;
    font-size: 40px;
    border: #ddd;
    margin-top: 5px;
    margin-bottom: 5px;
    
}
h2{
    margin-left: 600px;
    font-size: 30px;
}
p{
   background-color: #eee5e5;
}

</style>
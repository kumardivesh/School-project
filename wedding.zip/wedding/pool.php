<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
</head>
<body>
    <h1><b>Our Library</b></h1>
    <img src="liba.jpg" alt="This is an image"width="100%"height="600px";>
  
        <p>The design of systems for management and delivery of digital library content is an interdisciplinary area where research on digital libraries intersects with software development, database management, information retrieval, and human-computer interaction. 
            Digital library management systems (DLMS) share some similarities with web content management systems but are also different because of the required support for digital library standards, especially in regard to information organization and interoperability.
            DLMS represent a specialized category of software systems that integrate functionality for building, managing, storing, providing access to, and preserving digital objects and collections.
             They are part of a broader category of digital asset management systems that are used in practice for acquisition, indexing, storage, management, preservation, and delivery of digital objects. 
             In a distributed digital library environment, DLMS also provide platforms for aggregating digital content and metadata.</p>
    
    <h2><b> Types of books Available</b></h2>
    <table>
        <tr>
          <th>Name</th>
          <th>Contact</th>
          <th>Author </th>
        </tr>
        <tr>
          <td>Rich dead poor dead</td>
          <td>9876543210</td>
          <td>Robert kiyosaki and sharonlechter</td>
          <tr>
          <td> The Secret</td>
          <td>7895643210</td>
          <td>Rhonda vyrne</td></tr>
          
          <tr>
            <td>Daddy long legs</td>
            <td>6789453218</td>
            <td>Jean webstren</td>
          </tr>
          <tr>
            <td>Harry potter</td>
            <td>7865432190</td>
            <td>J.K.Rowling</td>
          </tr>
        <tr>
          <td>Fear not - be strong</td>
          <td>8765432190</td>
          <td>Swami thajatananda</td>
        </tr>
      </table>

    
</body>
</html>
<style>
table, td, th {  
  border: 1px solid #ddd;
  text-align: left;
}

table {
  border-collapse: collapse;
  width: 50%;
  margin-left: 370px;
  background-color: rgb(222, 218, 213);
  border-color: black;
}

th, td {
  padding: 15px;
  border-color: black;
}
h1{
    margin-left: 620px;
    font-size: 40px;
    border: #ddd;
    margin-top: 5px;
    margin-bottom: 5px;
    
}
h2{
    margin-left: 600px;
    font-size: 30px;
}
p{
   background-color: #eee5e5;
}

</style>
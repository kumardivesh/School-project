<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event management</title>
</head>
<body>
    <h1><b>School Events</b></h1>
    <section id="Event">
        <section class="activities-container">
           <h1 class="h-primary center"></h1><br>
        
           <div id="Event">
            
               <div class="box">
                <div class="container">
                    <!-- <img src="rep.jpg" alt="Norway" ">
                    <div class="text-block">
                      <h4>Republic Day</h4>
                       <p>What a beautiful sunrise</p> -->
                    
                   </div>
                <img src="rep.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
                <p class="text center"></p>
               </div>
               <div class="box">
                <img src="ind.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
                <p class="text center"></p> </p>
               </div>
               <div class="box">
                <img src="teacher.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
               </div>
               
               
           </div>
           

           <div id="Event">
            
               <div class="box">
                <img src="child.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
                <p class="text center"></p>
               </div>
               <div class="box">
                <img src="chris.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
                <p class="text center"></p> </p>
               </div>
               <div class="box">
                <img src="annu.jpg" alt="" class="src">   
                <h3 class="h-secondary center"></h3>
               </div>
               
               
           </div>
           <div id="Event">
            
            <div class="box">
             <img src="spo.jpg" alt="" class="src">   
             <h3 class="h-secondary center"></h3>
             <p class="text center"></p>
            </div>
            <div class="box">
             <img src="evnt1.jpg" alt="" class="src">   
             <h3 class="h-secondary center"></h3>
             <p class="text center"></p> </p>
            </div>
            <div class="box">
             <img src="img7.jpeg" alt="" class="src">   
             <h3 class="h-secondary center"></h3>
            </div>
            
            
        </div>
       </section>
</body>
</html>
<style>
    h1{
        /* margin-left: 750px; */
        font-size: 60px;
        margin-bottom: 2px;
        margin-top: 5px;
        bottom: 2px;
        text-align: center;

    }
    #Event{
        margin: 34px;
        display: flex;
    }
    #Event .box{
        border: 2px solid rgb(15, 15, 15);
        width: 350px;
        padding: 20px;
        /* margin: 2px 6px; */
        margin-left: 35px;
        margin-right: 38px;

        margin-bottom: 20px;
        border-radius: 28px;
        background:rgb(148, 175, 148);

    }
    #Event .box img{
        height: 250px;
        margin: 0px;
        display: block;
        width: 350px;
        margin-top: 20px;
        border: 2px solid black;
        border-radius: 10px;
    }
    .src{

    }
</style>
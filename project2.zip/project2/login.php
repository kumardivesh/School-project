<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
</head>
<body>
    <div class="container">
        <div class="title">Login Page</div>
        <form action = "login1.php">
        <div class="user-details">
            <div class="input-box">
                <span class="details">E-mail</span>
                <input type = "text" name="email" placeholder = "Enter your e-mail">
                </div>
                </div>
                <div class="user-details">
                <div class="input-box">
                    <span class="details">Password</span>
                    <input type = "text" name="password" placeholder = "Enter your password">
                    </div>
                </div>
                    <button class="btn1">Forgot Password</button>
                    <div>
                   <a href="index.php" target="blank"> <input type="submit" class="btn2" value="submit" ></a>
                    
                </div>
                
        
        </form>

    </div>
</body>
</html>
<style>
     body{
        display: flex;
        height: 100vh;
        justify-content: center;
        align-items: center;
        
    }
   .container{
    max-width: 500px;
    width: 100%;
    background: white;
    padding: 25px 30px;
    border-radius: 5px;
    background-color: #ddc8e6;
   }
   .container .title{
    font-size: 30px;
    font-weight: 500;
    font-style: oblique;
    
    position: relative;
   }
   .container .title::before{
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    

   }
   .container form .user-details{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    
   }
   form .user-details .input-box{
    margin-bottom: 15px;
      width: calc(100% / 2 - 20px);
      margin: 20px 0 12px 0 ;
   }
   .user-details .input-box .details{
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
   }
   .user-details .input-box input{
    height: 45px;
    width: 100%;
    outline: none;
    border-radius: 5px;
    border: 1px solid #ccc;
    padding-left: 15px;
    font-size: 16px;
    border-bottom-width: 2px;
   }
   .user-details .input-box input:focus,
   .user-details .input-box input:valid{
    border-color: #9b59b6;


   }
   .container form .btn1{
    text-align: center;
    border-radius: 5px;
    border-color: aliceblue;
    justify-content: space-between;
    margin-bottom: 5px;
   }
   .container form .btn2{
    width: 20%;
    margin-top: 5px;
    border-radius: 5px;
    border-color: aliceblue;
    background-color: rgb(227, 219, 219);
    font-size: medium;
    text-align: center;
    justify-content: center;

   }
   .btn2{
    cursor: pointer;
   }
   
</style>